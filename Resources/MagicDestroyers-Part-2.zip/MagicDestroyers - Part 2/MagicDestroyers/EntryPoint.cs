﻿namespace MagicDestroyers
{
    class EntryPoint
    {
        static void Main()
        {

        }
    }
}
