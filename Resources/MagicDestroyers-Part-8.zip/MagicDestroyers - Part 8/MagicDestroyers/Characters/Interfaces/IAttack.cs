﻿namespace MagicDestroyers.Characters.Interfaces
{
    public interface IAttack
    {
        int Attack();

        int SpecialAttack();
    }
}
