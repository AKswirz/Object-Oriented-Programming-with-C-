﻿namespace MagicDestroyers.Equipment.Interfaces
{
    public interface ISpecialItemAbility
    {
        void SpecialAbility();
    }
}
