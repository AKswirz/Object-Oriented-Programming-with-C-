﻿namespace MagicDestroyers.Equipment.Armors.Leather
{
    public abstract class Leather : Armor
    {

    }
}
