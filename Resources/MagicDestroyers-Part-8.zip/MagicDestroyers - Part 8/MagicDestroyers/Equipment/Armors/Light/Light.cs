﻿namespace MagicDestroyers.Equipment.Armors.Light
{
    public abstract class Light : Armor
    {

    }
}
