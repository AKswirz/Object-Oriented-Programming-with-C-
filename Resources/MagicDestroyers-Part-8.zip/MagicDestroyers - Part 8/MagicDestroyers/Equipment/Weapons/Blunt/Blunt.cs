﻿namespace MagicDestroyers.Equipment.Weapons.Blunt
{
    public abstract class Blunt : Weapon
    {
    }
}
