﻿namespace MagicDestroyers.Equipment.Weapons.Sharp
{
    public abstract class Sharp : Weapon
    {
    }
}
