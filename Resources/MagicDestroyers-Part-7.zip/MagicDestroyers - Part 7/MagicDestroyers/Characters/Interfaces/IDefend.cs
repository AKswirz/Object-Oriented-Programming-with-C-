﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagicDestroyers.Characters.Interfaces
{
    public interface IDefend
    {
        void Defend();
    }
}
