﻿namespace MagicDestroyers.Enums
{
    public enum Faction
    {
        Melee,
        Spellcaster
    }
}
