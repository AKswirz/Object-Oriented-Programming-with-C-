﻿namespace MagicDestroyers.Equipment.Armors.Heavy
{
    public class Heavy : Armor
    {

    }
}
