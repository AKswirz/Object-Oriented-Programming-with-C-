﻿namespace MagicDestroyers
{
    public static class PlayersInfo
    {
        private static string playersInfoDirectory = "";
        private static string[,] fullInfo;
        private static int[] scores;
        private static int[] levels;

        static PlayersInfo()
        {

        }

        public static void Save()
        {

        }

        public static void UpdateFullInfo()
        {

        }

        public static void RetrieveFullInfo()
        {

        }

        public static void PrintFullInfo()
        {

        }

        public static void EraseFullInfo()
        {

        }

        public static void UpdateScores()
        {

        }

        public static void RetrieveScores()
        {

        }

        public static void PrintScores()
        {

        }

        public static void EraseScores()
        {

        }

        public static void UpdateLevels()
        {

        }

        public static void RetrieveLevels()
        {

        }

        public static void PrintLevels()
        {

        }

        public static void EraseLevels()
        {

        }
    }
}
